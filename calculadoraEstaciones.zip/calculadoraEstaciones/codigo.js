mes = prompt("ingrese un numero de mes")
if (mes == 1) {
	alert("es enero y es Invierno")
	alert("jonathanVelasquez23004619")
}
else if ( mes == 2){
	alert("es febrero y es invierno ")
	alert("jonathanVelasquez23004619")
}
else if ( mes == 3){
	alert("es marzo y es primavera")
	alert("jonathanVelasquez23004619")
}
else if ( mes == 4){
	alert("es abril y es primavera")
	alert("jonathanVelasquez23004619")
}
else if ( mes == 5){
	alert("es mayo y es primavera")
	alert("jonathanVelasquez23004619")
}
else if ( mes == 6){
	alert("es junio y es verano")
	alert("jonathanVelasquez23004619")
}
else if ( mes == 7){
	alert("es julio y es verano")
	alert("jonathanVelasquez23004619")
}
else if ( mes == 8){
	alert("es agosto y es verano")
	alert("jonathanVelasquez23004619")
}
else if ( mes == 9){
	alert("es septiembre y es otono")
	alert("jonathanVelasquez23004619")
}
else if ( mes == 10){
	alert("es octubre y es otono")
	alert("jonathanVelasquez23004619")
}
else if ( mes == 11){
	alert("es noviembre y es otono")
	alert("jonathanVelasquez23004619")
}
else if ( mes == 12){
	alert("es diciembre y es invierno")
	alert("jonathanVelasquez23004619")
}
else if (mes => 13){
	alert("ingrese un numero valido")
	alert("jonathanVelasquez23004619")
}
